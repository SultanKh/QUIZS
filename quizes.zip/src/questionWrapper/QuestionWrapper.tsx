import React from "react";
import './QuestionWrapper.scss'
import Question, { questionProps } from '../question/question';

let QUESTION: questionProps
export interface QuestionWrapperProps {
}

interface QuestionPropsState {

}

enum type {
  openAnswer,
  multpleAnswer,
  selection
}


class QuestionWrapper extends React.Component<QuestionWrapperProps, QuestionPropsState> {
    callJson = async (questionType: string) => {
      const response = await fetch('http://localhost:3000/quizs/');
      const data = await response.json();
      const keys = Object.keys(data)
    
      for(let q in keys) {
        const mainKey = keys[q]
        if (data[mainKey].questionType === questionType) QUESTION = data[mainKey]
      }
      this.setState({...this.state})
    
    }


    render() {
        return (
            <div className='App'>
                <header className='App-header'>
                    <button className="button-28" onClick={() => this.callJson('openAnswer')}>Open Answer</button>
                    <button className="button-28" onClick={() => this.callJson('selection')}>Selection Quiz</button>
                    <button className="button-28" onClick={() => this.callJson('multpleAnswer')}> Multiple Quiz</button>
                </header>
                <div>
                    {QUESTION && <Question {...QUESTION} />}
                </div>
            </div>
        )
    }
 
}

export default QuestionWrapper;