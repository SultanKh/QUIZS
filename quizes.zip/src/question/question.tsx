import React from "react";
import './question.scss'

export interface questionProps {
    id: number,
    mainQuestion: string,
    questionField: string,
    questionType: string,
    options: string[],
    answer: string
}
class Question extends React.Component<questionProps> {


    render() {
        const openAnswerInput = <input key='openAnswerInput' type='text' placeholder='your answer..' />

        const radioButtonsQuestion = (<div className="radioButtons">
            {this.props.options.map(item => (
                <div key={`${item}.radioBtn`} className="answerOption">
                    <input type="radio" id={item} name={this.props.questionField} value={item} />
                    <label htmlFor={item}>{item}</label>
                    <br />
                </div>
            ))}
        </div>)

        const multiSelection = (<div className="answerOption">
                {
                    this.props.options.map(item => (
                        <div className="answerOption">
                            <input type="checkbox" id={item} name={this.props.questionField} value={item} />
                            <label htmlFor={item}> {item}</label>
                            <br/>
                        </div>
                    ))
                }
        </div>)

        return (
            <div className="card">
                <div className="container">
                    <h4>{this.props.mainQuestion}</h4>
                    {this.props.questionType === 'openAnswer' && openAnswerInput}
                    {this.props.questionType === 'selection' && radioButtonsQuestion}
                    {this.props.questionType === 'multpleAnswer' && multiSelection}
                </div>
            </div>
        )
    }
}

export default Question;