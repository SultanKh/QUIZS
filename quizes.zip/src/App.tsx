import React from 'react';
import './App.css';
import QuestionWrapper from './questionWrapper/QuestionWrapper';


function App() {

  return (
    <div className='App'>
      <header className='App-header'>
      </header>
      <div>
      <QuestionWrapper />
      </div>
    </div>
  );
}

export default App;

